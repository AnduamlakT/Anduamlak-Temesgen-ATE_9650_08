package com.example.anduamlaktemesgen.register;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity implements View.OnClickListener{
    private Button reg;
    private TextView tvLogin;
    private EditText etEmail, etPass;
    private DbConnector db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DbConnector(this);

        reg = (Button)findViewById(R.id.btnReg);
        tvLogin = (TextView)findViewById(R.id.tvLogin);
        etEmail = (EditText)findViewById(R.id.etEmail);
        etPass = (EditText)findViewById(R.id.etPass);
        reg.setOnClickListener(this);
        tvLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnReg:
                register();
                break;
            case R.id.tvLogin:
                startActivity(new Intent(Register.this, Login.class));
                finish();
                break;
            default:
        }
    }

    private void  register(){
        String email = etEmail.getText().toString();
        String pass = etPass.getText().toString();

        if (email.isEmpty() && pass.isEmpty()){
            displayToast("Username or Password Field Empty");
        }else {
            db.addUser(email, pass);
            displayToast("New User Registered Successfully");
        }
    }

    private void displayToast(String meg){
        Toast.makeText(getApplicationContext(), meg, Toast.LENGTH_SHORT).show();

    }



}
